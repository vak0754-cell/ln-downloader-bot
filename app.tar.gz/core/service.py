from __future__ import annotations

import asyncio
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Awaitable, Callable

import httpx

from config import Settings
from core.drive_uploader import DriveUploader
from core.epub_builder import build_epub, build_txt
from core.parsers import (
    PoliteHttpClient,
    SourcePlan,
    extract_clean_chapter_html,
    inspect_url,
    parse_range_spec,
    sanitize_filename,
)
from core.storage import DownloadStore


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@dataclass
class JobState:
    job_id: str
    url: str
    title: str
    mode: str
    fmt: str
    status: str = "queued"  # queued | running | done | cancelled | failed
    total: int = 0
    done: int = 0
    cached_hits: int = 0
    output_files: list[str] = field(default_factory=list)
    drive_urls: list[str] = field(default_factory=list)
    error: str = ""
    created_at: str = field(default_factory=_utc_now)
    updated_at: str = field(default_factory=_utc_now)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class DownloadService:
    """Shared async download engine used by Telegram Bot, REST API, and FastMCP server."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.settings.ensure_dirs()
        self.http = PoliteHttpClient(settings.user_agent, settings.request_timeout, settings.rate_limit_delay)
        self.store = DownloadStore(settings.data_dir / "cache" / "downloads.sqlite3")
        self.drive = DriveUploader(settings.drive_root_folder_id, settings.google_service_account_file)
        self.jobs: dict[str, JobState] = {}
        self.cancels: dict[str, asyncio.Event] = {}
        self.telegram_notifier: Callable[[Path, str], Awaitable[None]] | None = None

    async def inspect(self, url: str) -> SourcePlan:
        return await inspect_url(self.http, url)

    def get_job(self, job_id: str) -> dict[str, Any] | None:
        job = self.jobs.get(job_id)
        return job.to_dict() if job else None

    def list_jobs(self, limit: int = 20) -> list[dict[str, Any]]:
        items = sorted(self.jobs.values(), key=lambda j: j.created_at, reverse=True)
        return [j.to_dict() for j in items[:limit]]

    def cancel_job(self, job_id: str) -> bool:
        ev = self.cancels.get(job_id)
        if ev:
            ev.set()
            return True
        return False

    async def start_download(
        self,
        *,
        url: str,
        fmt: str = "epub",
        range_spec: str = "all",
        upload_to_drive: bool = True,
        notify_telegram: bool = True,
        user_id: int = 0,
    ) -> dict[str, Any]:
        plan = await self.inspect(url)
        job_id = uuid.uuid4().hex[:10]
        job = JobState(
            job_id=job_id,
            url=plan.source_url,
            title=plan.title,
            mode=plan.mode,
            fmt=fmt,
            status="running",
            total=len(plan.chapters) if plan.mode == "web_book" else (len(plan.files) or 1),
        )
        self.jobs[job_id] = job
        cancel_ev = asyncio.Event()
        self.cancels[job_id] = cancel_ev

        asyncio.create_task(
            self._run_job(
                job=job,
                plan=plan,
                range_spec=range_spec,
                upload_to_drive=upload_to_drive,
                notify_telegram=notify_telegram,
                user_id=user_id,
                cancel_ev=cancel_ev,
            )
        )
        return job.to_dict()

    async def _post_process_file(
        self, job: JobState, path: Path, upload_to_drive: bool, notify_telegram: bool
    ) -> None:
        job.output_files.append(str(path))
        if upload_to_drive and self.drive.enabled:
            slug = sanitize_filename(job.title).replace(" ", "_")
            up = await asyncio.to_thread(self.drive.upload, path, slug)
            if up.get("webViewLink"):
                job.drive_urls.append(up["webViewLink"])
        if notify_telegram and self.telegram_notifier:
            try:
                await self.telegram_notifier(path, job.title)
            except Exception:
                pass

    async def _run_job(
        self,
        *,
        job: JobState,
        plan: SourcePlan,
        range_spec: str,
        upload_to_drive: bool,
        notify_telegram: bool,
        user_id: int,
        cancel_ev: asyncio.Event,
    ) -> None:
        try:
            async with httpx.AsyncClient() as client:
                if plan.mode == "direct_file":
                    saved = await self.http.download_binary(
                        client, plan.source_url, self.settings.data_dir / "downloads", self.settings.max_file_mb
                    )
                    job.done = 1
                    await self._post_process_file(job, saved, upload_to_drive, notify_telegram)
                    self.store.add_history(user_id, plan.source_url, plan.title, 1, str(saved))

                elif plan.mode == "directory":
                    targets = [f for f in plan.files if job.fmt == "all" or f["ext"] == ".epub"] or plan.files
                    job.total = len(targets)
                    for finfo in targets:
                        if cancel_ev.is_set():
                            job.status = "cancelled"
                            job.updated_at = _utc_now()
                            return
                        saved = await self.http.download_binary(
                            client, finfo["url"], self.settings.data_dir / "downloads", self.settings.max_file_mb
                        )
                        job.done += 1
                        job.updated_at = _utc_now()
                        await self._post_process_file(job, saved, upload_to_drive, notify_telegram)
                        self.store.add_history(user_id, finfo["url"], finfo["name"], 1, str(saved))
                        await asyncio.sleep(self.settings.rate_limit_delay)

                else:
                    indices = parse_range_spec(range_spec, len(plan.chapters))
                    if not indices:
                        raise ValueError(f"Некоректний діапазон розділів: {range_spec}")
                    selected = [plan.chapters[i - 1] for i in indices]
                    job.total = len(selected)

                    cover_bytes: bytes | None = None
                    cover_ext = ".jpg"
                    if plan.cover_url and job.fmt == "epub":
                        try:
                            cresp = await client.get(plan.cover_url, timeout=15, follow_redirects=True)
                            if cresp.status_code == 200 and len(cresp.content) < 5 * 1024 * 1024:
                                cover_bytes = cresp.content
                                if "png" in cresp.headers.get("content-type", "").lower():
                                    cover_ext = ".png"
                        except Exception:
                            pass

                    sem = asyncio.Semaphore(self.settings.concurrency)
                    results: dict[int, dict[str, str]] = {}
                    lock = asyncio.Lock()

                    async def fetch_one(pos: int, ch_url: str, fallback_title: str) -> None:
                        if cancel_ev.is_set():
                            return
                        cached = self.store.get_cached_chapter(ch_url)
                        if cached:
                            results[pos] = cached
                            async with lock:
                                job.cached_hits += 1
                                job.done += 1
                                job.updated_at = _utc_now()
                            return
                        async with sem:
                            if cancel_ev.is_set():
                                return
                            try:
                                raw_html, _ = await self.http.get_text(client, ch_url)
                                parsed_title, body_html = extract_clean_chapter_html(raw_html)
                                item = {"title": parsed_title or fallback_title, "body_html": body_html}
                                self.store.save_cached_chapter(ch_url, item["title"], item["body_html"])
                                results[pos] = item
                            except Exception as exc:
                                results[pos] = {"title": fallback_title, "body_html": f"<p>[Error: {exc}]</p>"}
                            await asyncio.sleep(self.settings.rate_limit_delay)
                        async with lock:
                            job.done += 1
                            job.updated_at = _utc_now()

                    await asyncio.gather(*(fetch_one(i, ch.url, ch.title) for i, ch in enumerate(selected)))
                    if cancel_ev.is_set():
                        job.status = "cancelled"
                        job.updated_at = _utc_now()
                        return

                    ordered = [results[i] for i in range(len(selected)) if i in results]
                    fname = sanitize_filename(f"{plan.title}_{indices[0]}-{indices[-1]}")
                    books_dir = self.settings.data_dir / "books"
                    if job.fmt == "txt":
                        out_path = await asyncio.to_thread(
                            build_txt, title=plan.title, author=plan.author, chapters=ordered, out_path=books_dir / f"{fname}.txt"
                        )
                    else:
                        out_path = await asyncio.to_thread(
                            build_epub,
                            title=plan.title,
                            author=plan.author,
                            chapters=ordered,
                            out_path=books_dir / f"{fname}.epub",
                            cover_bytes=cover_bytes,
                            cover_ext=cover_ext,
                        )
                    await self._post_process_file(job, out_path, upload_to_drive, notify_telegram)
                    self.store.add_history(user_id, plan.source_url, plan.title, len(ordered), str(out_path))

            job.status = "done"
            job.updated_at = _utc_now()
        except Exception as exc:
            job.status = "failed"
            job.error = str(exc)
            job.updated_at = _utc_now()
        finally:
            self.cancels.pop(job.job_id, None)
