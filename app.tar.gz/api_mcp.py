from __future__ import annotations

from pathlib import Path
from typing import Any

import hmac
import os
from urllib.parse import parse_qs

from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.responses import FileResponse
from fastmcp import FastMCP
from pydantic import BaseModel, Field

from core.service import DownloadService


class _McpGate:
    """ASGI middleware: serve exact `/mcp` (no 307 redirect to `/mcp/`) and optionally require a key.

    If MCP_REQUIRE_KEY=true and API_KEY is set, /mcp requires `Authorization: Bearer <API_KEY>`
    or a `?key=<API_KEY>` query parameter (for clients that can't send headers).
    """

    def __init__(self, app, api_key: str = "", require_key: bool = False) -> None:
        self.app = app
        self.api_key = api_key.strip()
        self.require_key = require_key and bool(self.api_key)

    async def __call__(self, scope, receive, send):
        path = str(scope.get("path", ""))
        if scope["type"] in ("http", "websocket") and (path == "/mcp" or path.startswith("/mcp/")):
            if self.require_key and scope["type"] == "http":
                headers = {k.decode().lower(): v.decode() for k, v in scope.get("headers", [])}
                supplied = headers.get("authorization", "").removeprefix("Bearer ").strip()
                if not supplied:
                    qs = parse_qs(scope.get("query_string", b"").decode())
                    supplied = (qs.get("key") or [""])[0]
                if not hmac.compare_digest(supplied, self.api_key):
                    body = b'{"detail":"Invalid or missing key"}'
                    await send({"type": "http.response.start", "status": 401,
                                "headers": [(b"content-type", b"application/json"),
                                            (b"content-length", str(len(body)).encode())]})
                    await send({"type": "http.response.body", "body": body})
                    return
            if scope.get("path") == "/mcp":
                scope = dict(scope)
                scope["path"] = "/mcp/"
                if scope.get("raw_path"):
                    scope["raw_path"] = b"/mcp/"
        await self.app(scope, receive, send)


class InspectRequest(BaseModel):
    url: str


class DownloadRequest(BaseModel):
    url: str
    fmt: str = Field("epub", description="Формат: epub | txt | all")
    range_spec: str = Field("all", description="Діапазон розділів: all, 1-50, 10,15-20")
    upload_to_drive: bool = True
    notify_telegram: bool = True


def create_app(service: DownloadService) -> FastAPI:
    """Create combined FastAPI REST API + FastMCP server for remote control from Gemini."""
    mcp = FastMCP("LN Downloader Bot")

    @mcp.tool()
    async def inspect_novel_url(url: str) -> dict[str, Any]:
        """Inspect a novel/ebook URL and return detected mode, title, author, chapter count, or file list."""
        plan = await service.inspect(url)
        return {
            "mode": plan.mode,
            "source_url": plan.source_url,
            "title": plan.title,
            "author": plan.author,
            "cover_url": plan.cover_url,
            "chapters_count": len(plan.chapters),
            "sample_chapters": [
                {"index": c.index, "title": c.title, "url": c.url} for c in plan.chapters[:10]
            ],
            "files": plan.files[:50],
        }

    @mcp.tool()
    async def start_novel_download(
        url: str,
        fmt: str = "epub",
        range_spec: str = "all",
        upload_to_drive: bool = True,
        notify_telegram: bool = True,
    ) -> dict[str, Any]:
        """Start an async download job by URL, compile EPUB/TXT, and optionally upload to Google Drive & Telegram."""
        return await service.start_download(
            url=url,
            fmt=fmt,
            range_spec=range_spec,
            upload_to_drive=upload_to_drive,
            notify_telegram=notify_telegram,
        )

    @mcp.tool()
    async def get_download_status(job_id: str) -> dict[str, Any]:
        """Check live progress, output files, and Google Drive links for a download job."""
        job = service.get_job(job_id)
        if not job:
            return {"error": f"Job '{job_id}' not found"}
        return job

    @mcp.tool()
    async def list_download_jobs(limit: int = 15) -> list[dict[str, Any]]:
        """List recent download jobs and their statuses."""
        return service.list_jobs(limit=limit)

    @mcp.tool()
    async def cancel_download_job(job_id: str) -> dict[str, Any]:
        """Cancel a running download job (already downloaded chapters stay cached)."""
        ok = service.cancel_job(job_id)
        return {"job_id": job_id, "cancelled": ok}

    mcp_app = mcp.http_app(path="/")

    app = FastAPI(title="LN Downloader Bot API + MCP", version="1.0.0", lifespan=mcp_app.lifespan)

    def verify_api_key(authorization: str = Header(default="")) -> None:
        expected = service.settings.api_key.strip()
        if not expected:
            return
        token = authorization.removeprefix("Bearer ").strip()
        if token != expected:
            raise HTTPException(status_code=401, detail="Invalid or missing Bearer API_KEY")

    @app.get("/")
    async def root() -> dict[str, str]:
        return {"status": "ok"}

    @app.get("/health")
    async def health() -> dict[str, Any]:
        return {
            "status": "ok",
            "drive_enabled": service.drive.enabled,
            "active_jobs": sum(1 for j in service.jobs.values() if j.status == "running"),
        }

    @app.post("/api/inspect", dependencies=[Depends(verify_api_key)])
    async def api_inspect(req: InspectRequest) -> dict[str, Any]:
        try:
            plan = await service.inspect(req.url)
            return {
                "mode": plan.mode,
                "source_url": plan.source_url,
                "title": plan.title,
                "author": plan.author,
                "chapters_count": len(plan.chapters),
                "files": plan.files,
            }
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/api/download", dependencies=[Depends(verify_api_key)])
    async def api_download(req: DownloadRequest) -> dict[str, Any]:
        try:
            return await service.start_download(
                url=req.url,
                fmt=req.fmt,
                range_spec=req.range_spec,
                upload_to_drive=req.upload_to_drive,
                notify_telegram=req.notify_telegram,
            )
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.get("/api/jobs", dependencies=[Depends(verify_api_key)])
    async def api_jobs(limit: int = 20) -> list[dict[str, Any]]:
        return service.list_jobs(limit=limit)

    @app.get("/api/jobs/{job_id}", dependencies=[Depends(verify_api_key)])
    async def api_job_detail(job_id: str) -> dict[str, Any]:
        job = service.get_job(job_id)
        if not job:
            raise HTTPException(status_code=404, detail="Job not found")
        return job

    @app.post("/api/jobs/{job_id}/cancel", dependencies=[Depends(verify_api_key)])
    async def api_job_cancel(job_id: str) -> dict[str, Any]:
        return {"job_id": job_id, "cancelled": service.cancel_job(job_id)}

    @app.get("/api/files/{filename}", dependencies=[Depends(verify_api_key)])
    async def api_get_file(filename: str) -> FileResponse:
        safe_name = Path(filename).name
        for folder in (service.settings.data_dir / "books", service.settings.data_dir / "downloads"):
            candidate = folder / safe_name
            if candidate.exists() and candidate.is_file():
                return FileResponse(candidate, filename=safe_name)
        raise HTTPException(status_code=404, detail="File not found")

    app.mount("/mcp", mcp_app)
    app.add_middleware(
        _McpGate,
        api_key=service.settings.api_key,
        require_key=os.environ.get("MCP_REQUIRE_KEY", "").lower() in ("1", "true", "yes"),
    )
    return app
