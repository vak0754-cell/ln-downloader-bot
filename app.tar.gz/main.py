from __future__ import annotations

import asyncio
import hashlib
import logging
import os
from pathlib import Path

import uvicorn
from aiogram import Bot, Dispatcher
from aiogram.types import FSInputFile, Update
from fastapi import FastAPI, HTTPException, Request

import bot as tg_bot
from api_mcp import create_app
from config import Settings
from core.service import DownloadService

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("ln_downloader_main")

_BG_TASKS: set[asyncio.Task] = set()


def _webhook_base_url() -> str:
    return (os.environ.get("WEBHOOK_BASE_URL") or os.environ.get("RENDER_EXTERNAL_URL") or "").strip()


def _add_webhook_route(app: FastAPI, bot: Bot, dp: Dispatcher, path: str, secret: str) -> None:
    @app.post(path, include_in_schema=False)
    async def telegram_webhook(request: Request) -> dict[str, bool]:
        if secret and request.headers.get("X-Telegram-Bot-Api-Secret-Token", "") != secret:
            raise HTTPException(status_code=403, detail="bad secret")
        update = Update.model_validate(await request.json(), context={"bot": bot})
        # Handle in the background so Telegram gets a fast 200 (downloads can take minutes).
        task = asyncio.create_task(dp.feed_update(bot, update))
        _BG_TASKS.add(task)
        task.add_done_callback(_BG_TASKS.discard)
        return {"ok": True}


async def run_all() -> None:
    settings = Settings()
    service = DownloadService(settings)

    bot = Bot(token=settings.bot_token)
    dp = Dispatcher()
    dp.include_router(tg_bot.router)

    async def notify_telegram(path: Path, title: str) -> None:
        chat_id = settings.notify_chat_id or next(iter(settings.allowed_user_ids), 0)
        if not chat_id:
            return
        size_mb = round(path.stat().st_size / (1024 * 1024), 2)
        if size_mb <= 48.0:
            await bot.send_document(
                chat_id=chat_id,
                document=FSInputFile(path),
                caption=f"🤖 Завантажено через API/MCP: <code>{path.name}</code> ({size_mb} МБ)",
                parse_mode="HTML",
            )
        else:
            await bot.send_message(
                chat_id=chat_id,
                text=f"🤖 Завантажено через API/MCP: <b>{title}</b> ({size_mb} МБ, збережено на сервері / Google Drive).",
                parse_mode="HTML",
            )

    service.telegram_notifier = notify_telegram

    base_url = _webhook_base_url()
    use_webhook = bool(base_url)
    # Render injects $PORT; it must win over API_PORT. In webhook mode the HTTP server is mandatory.
    port = int(os.environ.get("PORT") or settings.api_port)
    tasks: list[asyncio.Task] = []

    if settings.enable_api or use_webhook:
        app = create_app(service)
        if use_webhook:
            secret = os.environ.get("WEBHOOK_SECRET", "")
            path = "/webhook/" + hashlib.sha256(settings.bot_token.encode()).hexdigest()[:24]
            _add_webhook_route(app, bot, dp, path, secret)
            await bot.set_webhook(
                base_url.rstrip("/") + path,
                secret_token=secret or None,
                allowed_updates=dp.resolve_used_update_types(),
            )
            logger.info("Telegram webhook set (mode: webhook).")
        server = uvicorn.Server(uvicorn.Config(app, host=settings.api_host, port=port, log_level="info"))
        tasks.append(asyncio.create_task(server.serve()))
        logger.info("REST API + MCP listening on http://%s:%s (MCP: /mcp)", settings.api_host, port)

    if not use_webhook:
        await bot.delete_webhook()
        tasks.append(asyncio.create_task(dp.start_polling(bot)))
        logger.info("Telegram polling started.")

    await asyncio.gather(*tasks)


if __name__ == "__main__":
    asyncio.run(run_all())
